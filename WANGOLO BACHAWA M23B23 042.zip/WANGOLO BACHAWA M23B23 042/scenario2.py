beatles = []
beatles.append("John Lenon")
beatles.append("Paul McCartney")
beatles.append("George Harrison")
print(beatles)
print("Add the new names on the list")
for i in range(2):
    new_beatles = str(input())
    beatles.append(new_beatles)
print(beatles)
del beatles[-2:]
print(beatles)
beatles.insert(0, "Ringo Starr")
print(beatles)
