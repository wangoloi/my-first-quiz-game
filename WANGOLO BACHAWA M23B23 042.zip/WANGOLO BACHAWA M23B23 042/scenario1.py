counting_numbers = [1, 2, 3, 4, 5]
counting_numbers[2] = int(
    input("Enter the number: ")
)  # this allows the user to replace that counting number in position
print(counting_numbers)
del counting_numbers[4]  # deletes the last counting number in the list
print(counting_numbers)
print(len(counting_numbers))  # length of the list
