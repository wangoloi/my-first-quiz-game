list = [1, 3, 2, 4, 3, 5, 4, 6]
unique_list = []
for num in list:
    if num not in unique_list:
        unique_list.append(num)

print("The original list with repeated numbers:", list)
print("The list with no repeated numbers:", unique_list)
